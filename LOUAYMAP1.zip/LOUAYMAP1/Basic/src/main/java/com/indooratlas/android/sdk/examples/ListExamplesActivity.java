package com.indooratlas.android.sdk.examples;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**

 */
public class ListExamplesActivity extends AppCompatActivity {

    private static final String TAG = "IAExample";

    private static final int REQUEST_CODE_PERMISSIONS = 1;

    private ExamplesAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.red)));

        mAdapter = new ExamplesAdapter(this);
        ListView listView = (ListView) findViewById(android.R.id.list);
        listView.setAdapter(mAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ComponentName example = mAdapter.mExamples.get(position).mComponentName;
                startActivity(new Intent(Intent.ACTION_VIEW).setComponent(example));
            }
        });

        if (!isSdkConfigured()) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.configuration_incomplete_title)
                    .setMessage(R.string.configuration_incomplete_message)
                    .setPositiveButton(R.string.button_ok, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    }).show();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isSdkConfigured()) {
            ensurePermissions();
        }
    }

    public static boolean checkLocationPermissions(Activity activity) {
        boolean loc = ContextCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // required with Android 12+ and targetSdkVersion >= 31
            boolean scan = ContextCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED;
            return loc && scan;
        } else {
            return loc;
        }
    }

    /**
     * Checks that we have access to required information, if not ask for users permission.
     */
    private void ensurePermissions() {
        boolean needBLEScanPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S;
        final List<String> permissions = new ArrayList<>(Arrays.asList(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION));
        if (needBLEScanPermission) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN);
        }

        if (!checkLocationPermissions(this)) {
            // We don't have access to ACCESS_FINE_LOCATION and/or BLUETOOTH_SCAN permissions
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION) ||
                    (needBLEScanPermission && ActivityCompat.shouldShowRequestPermissionRationale(
                            this, Manifest.permission.BLUETOOTH_SCAN))) {

                new AlertDialog.Builder(this)
                        .setTitle(R.string.location_permission_request_title)
                        .setMessage(R.string.location_permission_request_rationale)
                        .setPositiveButton(R.string.permission_button_accept, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Log.d(TAG, "request permissions");
                                ActivityCompat.requestPermissions(ListExamplesActivity.this,
                                        permissions.toArray(new String[]{}),
                                        REQUEST_CODE_PERMISSIONS);
                            }
                        })
                        .setNegativeButton(R.string.permission_button_deny, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(ListExamplesActivity.this,
                                        R.string.location_permission_denied_message,
                                        Toast.LENGTH_LONG).show();
                            }
                        })
                        .show();

            } else {
                // ask user for permissions
                ActivityCompat.requestPermissions(this,
                        permissions.toArray(new String[]{}),
                        REQUEST_CODE_PERMISSIONS);
            }

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (grantResults.length == 0
                    || grantResults[0] == PackageManager.PERMISSION_DENIED) {
                Toast.makeText(this, R.string.location_permission_denied_message,
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * Adapter for example activities.
     */
    class ExamplesAdapter extends BaseAdapter {

        final ArrayList<ExampleEntry> mExamples;

        ExamplesAdapter(Context context) {
            mExamples = listActivities(context);
        }


        @Override
        public int getCount() {
            return mExamples.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ExampleEntry entry = mExamples.get(position);
            if (convertView == null) {
                convertView = getLayoutInflater().inflate(android.R.layout.simple_list_item_2,
                        parent, false);
            }
            TextView labelText = (TextView) convertView.findViewById(android.R.id.text1);
            TextView descriptionText = (TextView) convertView.findViewById(android.R.id.text2);
            labelText.setText(entry.mLabel);
            descriptionText.setText(entry.mDescription);
            return convertView;
        }
    }


    /**
     * Returns a list of activities that are part of this application, skipping
     * those from included libraries and *this* activity.
     */
    public ArrayList<ExampleEntry> listActivities(Context context) {

        ArrayList<ExampleEntry> result = new ArrayList<>();
        try {
            final String packageName = context.getPackageName();
            PackageManager pm = context.getPackageManager();
            PackageInfo info = pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);

            for(ActivityInfo activityInfo : info.activities) {
                parseExample(activityInfo, result);
            }

            return result;

        } catch (Exception e) {
            throw new IllegalStateException("failed to get list of activities", e);
        }

    }

    private void parseExample(ActivityInfo info, ArrayList<ExampleEntry> list) {
        try {
            Class<?> cls = Class.forName(info.name);
            if (cls.isAnnotationPresent(SdkExample.class)) {
                SdkExample annotation = (SdkExample) cls.getAnnotation(SdkExample.class);
                list.add(new ExampleEntry(new ComponentName(info.packageName, info.name),
                        annotation.title() != -1
                                ? getString(annotation.title())
                                : info.loadLabel(getPackageManager()).toString(),
                        getString(annotation.description())));
            }
        } catch (ClassNotFoundException e) {
            Log.e(TAG, "failed to read example info for class: " + info.name, e);
        }

    }


    static class ExampleEntry implements Comparable<ExampleEntry> {

        final ComponentName mComponentName;

        final String mLabel;

        final String mDescription;

        ExampleEntry(ComponentName name, String label, String description) {
            mComponentName = name;
            mLabel = label;
            mDescription = description;
        }

        @Override
        public int compareTo(ExampleEntry another) {
            return mLabel.compareTo(another.mLabel);
        }
    }


    private boolean isSdkConfigured() {
        return !"api-key-not-set".equals(getString(R.string.indooratlas_api_key))
                && !"api-secret-not-set".equals(getString(R.string.indooratlas_api_secret));
    }


}
