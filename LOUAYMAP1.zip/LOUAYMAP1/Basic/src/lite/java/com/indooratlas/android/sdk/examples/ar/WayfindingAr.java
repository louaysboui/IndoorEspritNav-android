package com.indooratlas.android.sdk.examples.ar;

// dummy class for non-AR build
public class WayfindingAr {}
