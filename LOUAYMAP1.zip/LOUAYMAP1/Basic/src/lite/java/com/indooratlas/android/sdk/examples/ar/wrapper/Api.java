package com.indooratlas.android.sdk.examples.ar.wrapper;

public interface Api {
    public interface ARAvailabilityCallback {
        void onARAvailability(boolean available);
    }
}
